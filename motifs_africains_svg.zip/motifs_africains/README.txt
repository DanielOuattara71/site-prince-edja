MOTIFS AFRICAINS — FICHIERS SVG
================================

Contenu :
- motif-linear-01.svg
- motif-spiral-02.svg
- motif-circulaire-03.svg
- motif-symetrique-04.svg
- motif-lineaire-05.svg

Les fichiers sont des SVG vectoriels modifiables. La couleur de trait actuelle est #4B3018.
Pour modifier la couleur, remplacez cette valeur dans l'attribut stroke.
Pour les intégrer au site, copiez les fichiers dans le dossier public/assets/motifs (ou le dossier d'assets adapté au projet).

Exemple HTML :
<img src="/assets/motifs/motif-spiral-02.svg" alt="" aria-hidden="true">

Pour une décoration d'arrière-plan, pensez à appliquer pointer-events: none et à vérifier l'opacité et le responsive.
Ces dessins sont des interprétations graphiques originales inspirées de l'image de référence, pas une certification de leur origine ou de leur signification culturelle.
