import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router'
import { lireTableauDeBord } from '@/api/endpoints/contenus'
import { useSession } from '@/auth/contexte-session'
import { peut, type CompteDroits } from '@/auth/permissions'
import { EtatErreur } from '@/components/ui/Etats'
import { PastilleStatut } from '@/components/ui/PastilleStatut'
import { TitrePage } from '@/components/layout/TitrePage'
import { Squelette } from '@/components/ui/Squelette'
import { t, type CleTraduction } from '@/i18n/fr'
import { formaterDateHeure } from '@/lib/dates'
import { etatAffiche } from '@/lib/statuts'

/**
 * Tableau de bord, version de l'étape 2 : les compteurs du contrat (§ 16). Les compteurs de
 * messages et de demandes n'apparaissent qu'aux rôles qui peuvent les traiter. La version
 * complète (dernières modifications cliquables, suivi détaillé) arrive à l'étape 9.
 */
export default function TableauDeBord() {
  const { moi } = useSession()
  const requete = useQuery({ queryKey: ['tableau-de-bord'], queryFn: lireTableauDeBord })
  const compte = moi?.compte

  return (
    <section className="space-y-8">
      <div className="space-y-2">
        <TitrePage titre={t('accueil.titre')}>{t('accueil.titre')}</TitrePage>
        {compte ? (
          <p className="text-body-lg text-ink-700">
            {t('accueil.bonjour')} {compte.nom}.
          </p>
        ) : null}
      </div>

      {requete.isPending ? <Squelette lignes={4} /> : null}

      {requete.isError ? (
        <EtatErreur erreur={requete.error} surReessai={() => void requete.refetch()} />
      ) : null}

      {requete.data ? (
        <>
          <dl className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            <Compteur libelle={t('accueil.aRelire')} valeur={requete.data.aRelire} />
            <Compteur libelle={t('accueil.brouillons')} valeur={requete.data.brouillons} />
            <Compteur libelle={t('accueil.aFournir')} valeur={requete.data.aFournir} />
            {peut(compte, 'lire', 'messages') ? (
              <Compteur libelle={t('accueil.messages')} valeur={requete.data.messagesNonLus} />
            ) : null}
            {peut(compte, 'lire', 'demandes') ? (
              <Compteur libelle={t('accueil.demandes')} valeur={requete.data.demandesNouvelles} />
            ) : null}
          </dl>

          <div className="space-y-2">
            <h2 className="font-display text-heading-sm uppercase text-ink-900">
              {t('accueil.reconstruction')}
            </h2>
            <p className="text-body text-ink-700">
              {requete.data.derniereReconstruction
                ? `${t(`publication.${requete.data.derniereReconstruction.etat}` as CleTraduction)} — ${formaterDateHeure(
                    requete.data.derniereReconstruction.declencheeLe,
                  )}`
                : t('accueil.aucuneReconstruction')}
            </p>
            {peut(compte, 'lire', 'site') ? (
              <Link
                to="/publication"
                className="inline-flex min-h-11 items-center font-semibold text-clay-600 hover:underline"
              >
                {t('menu.publication')}
              </Link>
            ) : null}
          </div>

          {requete.data.dernieresModifications.length > 0 ? (
            <div className="space-y-3">
              <h2 className="font-display text-heading-sm uppercase text-ink-900">
                {t('accueil.dernieresModifications')}
              </h2>
              <ul className="divide-y divide-sand-200 rounded-md border border-sand-200 bg-sand-100">
                {requete.data.dernieresModifications.map((modification) => {
                  const chemin = CHEMIN_MODIFICATION[modification.ressource]?.(modification.id)
                  const titre = modification.titre || t('declaratif.sansTitre')
                  const contenu = (
                    <>
                      <span className="font-semibold text-ink-900">{titre}</span>
                      <span className="flex flex-wrap items-center gap-2 text-caption text-ink-700">
                        {modification.statut ? (
                          <PastilleStatut etat={etatAffiche(modification.statut, null)} />
                        ) : null}
                        <span>{formaterDateHeure(modification.modifieLe)}</span>
                        <span>{modification.auteur?.nom ?? '—'}</span>
                      </span>
                    </>
                  )
                  return (
                    <li key={`${modification.ressource}-${modification.id}`} className="px-4 py-3">
                      {chemin ? (
                        <Link
                          to={chemin}
                          className="flex min-h-11 flex-col justify-center gap-1 hover:underline"
                        >
                          {contenu}
                        </Link>
                      ) : (
                        <div className="flex min-h-11 flex-col justify-center gap-1">{contenu}</div>
                      )}
                    </li>
                  )
                })}
              </ul>
            </div>
          ) : null}

          {liensAdministration(compte).length > 0 ? (
            <nav aria-labelledby="administration-titre" className="space-y-3">
              <h2
                id="administration-titre"
                className="font-display text-heading-sm uppercase text-ink-900"
              >
                {t('accueil.administration')}
              </h2>
              <ul className="grid gap-3 sm:grid-cols-2">
                {liensAdministration(compte).map((lien) => (
                  <li key={lien.chemin}>
                    <Link
                      to={lien.chemin}
                      className="inline-flex min-h-11 items-center rounded-md border border-sand-200 px-4 font-semibold text-ink-900 hover:bg-sand-100"
                    >
                      {lien.libelle}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ) : null}
        </>
      ) : null}
    </section>
  )
}

const CHEMIN_MODIFICATION: Record<string, (id: string) => string> = {
  articles: (id) => `/articles/${id}`,
  episodes: (id) => `/episodes/${id}`,
  projets: (id) => `/projets/${id}`,
  villes: (id) => `/villes/${id}`,
  destinations: (id) => `/destinations/${id}`,
  archive: (id) => `/archive/${id}`,
  distinctions: (id) => `/distinctions/${id}`,
  presse: (id) => `/presse/${id}`,
  univers: (id) => `/univers/${id}`,
  jalons: (id) => `/jalons/${id}`,
  offres: (id) => `/offres/${id}`,
  pages: (id) => `/pages/${id}`,
  bijoux: (id) => `/bijoux/${id}`,
  createurs: (id) => `/createurs/${id}`,
}

function liensAdministration(
  compte: CompteDroits | undefined,
): { chemin: string; libelle: string }[] {
  const liens: { chemin: string; libelle: string }[] = []
  if (peut(compte, 'lire', 'comptes'))
    liens.push({ chemin: '/comptes', libelle: t('menu.comptes') })
  if (peut(compte, 'lire', 'journal'))
    liens.push({ chemin: '/journal', libelle: t('menu.journal') })
  return liens
}

function Compteur({ libelle, valeur }: { libelle: string; valeur: number }) {
  return (
    <div className="rounded-md border border-sand-200 bg-sand-100 p-5">
      <dt className="text-body text-ink-700">{libelle}</dt>
      <dd className="mt-1 font-display text-heading-md text-ink-900 tnum">{valeur}</dd>
    </div>
  )
}
