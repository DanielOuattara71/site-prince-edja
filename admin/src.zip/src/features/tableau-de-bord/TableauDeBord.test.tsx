import { render, screen, within } from '@testing-library/react'
import { afterEach, describe, expect, it } from 'vitest'
import { App } from '@/app/App'
import { utiliserFauxServeur, connecter, type RoleEssai } from '@/test/faux-serveur'
import { violationsGraves } from '@/test/axe'

/**
 * Étape 9 — tableau de bord : les dernières modifications sont cliquables, et les
 * raccourcis d’administration n’apparaissent qu’aux comptes autorisés.
 */
utiliserFauxServeur()
afterEach(() => window.history.pushState({}, '', '/'))

async function ouvrir(role: RoleEssai, chemin: string) {
  await connecter(role)
  window.history.pushState({}, '', chemin)
  return render(<App />)
}

describe('tableau de bord (étape 9)', () => {
  it('affiche les dernières modifications cliquables et l’espace Administration pour un admin', async () => {
    const { container } = await ouvrir('admin', '/')
    expect(await screen.findByRole('heading', { name: 'Tableau de bord' })).toBeTruthy()
    expect(await screen.findByRole('heading', { name: 'Dernières modifications' })).toBeTruthy()
    const administration = screen.getByRole('navigation', { name: 'Administration' })
    expect(within(administration).getByRole('link', { name: 'Comptes' }).getAttribute('href')).toBe(
      '/comptes',
    )
    expect(within(administration).getByRole('link', { name: 'Journal' }).getAttribute('href')).toBe(
      '/journal',
    )
    expect(await violationsGraves(container)).toEqual([])
  })

  it('un éditeur ne voit pas l’espace Administration', async () => {
    const { container } = await ouvrir('editeur', '/')
    expect(await screen.findByRole('heading', { name: 'Tableau de bord' })).toBeTruthy()
    expect(screen.queryByRole('navigation', { name: 'Administration' })).toBeNull()
    expect(await violationsGraves(container)).toEqual([])
  })
})
