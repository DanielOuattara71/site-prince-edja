import type { MouseEventHandler } from 'react'
import { Link } from 'react-router'
import { LazyImage } from '@/components/media/LazyImage'
import { srcsetContenu, SIZES_CARTE } from '@/lib/visuels'

interface FilmRowProps {
  numero: string
  titre: string
  lieu: string
  pitch?: string
  image: string
  to: string
  onEnter: MouseEventHandler<HTMLAnchorElement>
  onLeave: MouseEventHandler<HTMLAnchorElement>
}

export function FilmRow({
  numero,
  titre,
  lieu,
  pitch,
  image,
  to,
  onEnter,
  onLeave,
}: FilmRowProps) {
  return (
    <Link
      to={to}
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
      className="group grid grid-cols-[auto_1fr_auto] items-baseline gap-x-4 gap-y-2 border-t border-cream-100/25 py-7 transition-colors duration-(--d-base) hover:border-clay-500/70 sm:py-9"
    >
      <span aria-hidden className="font-display text-heading-sm text-gold-400">
        {numero}
      </span>

      <div className="min-w-0">
        <h3 className="truncate font-display uppercase text-heading-md transition-colors duration-(--d-base) group-hover:text-clay-500 sm:text-display-lg sm:group-hover:text-clay-500">
          {titre}
        </h3>
        <LazyImage
          src={image}
          srcSet={srcsetContenu(image)}
          sizes={SIZES_CARTE}
          alt=""
          ratio="16/10"
          className="mt-4 rounded-md lg:hidden"
        />
        {pitch && (
          <p className="mt-2 max-w-md text-caption text-cream-100/60">{pitch}</p>
        )}
      </div>

      <div className="flex flex-col items-end gap-2 self-center">
        <span className="label-caps text-cream-100/60">{lieu}</span>
      </div>
    </Link>
  )
}
