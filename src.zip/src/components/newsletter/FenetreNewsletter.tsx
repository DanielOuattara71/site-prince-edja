import { useEffect, useRef, useState, type FormEvent } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { PROMESSE_NEWSLETTER } from '@/data/newsletter'
import { Button } from '@/components/ui/Button'
import { SectionHeading } from '@/components/ui/SectionHeading'
import { estInscrit, emailValide, consignerIntention, marquerInscrit, VERSION_CONSENTEMENT } from '@/lib/newsletter'
import { useLangue } from '@/i18n/contexteLangue'
import { DUR, EASE_EXPO } from '@/lib/motion'

/**
 * Fenêtre d'inscription à la lettre du Griot.
 *
 * Déclenchée une fois, après environ 20 s de navigation, sur les pages de
 * contenu. Le verrou de fermeture est posé en localStorage (30 j) : le visiteur
 * qui ferme ne la revoira pas avant. Un marqueur d'inscription existant ferme le
 * cycle : jamais de seconde sollicitation après acceptation.
 *
 * Accessibilité et ergonomie : fermeture Échap / bouton / clic extérieur, focus
 * amarré à l'ouverture puis rendu à la fermeture, bloque le scroll pendant
 * l'ouverture, respire la réduction de mouvement. Altitude z-80 (étage modales,
 * échelle maison).
 */

const CLE_MODAL_VERROU = 'pe_newsletter_modal_verrou'
const DUR_MODALE_PRESENCE = 20
const DUR_MODALE_FERME = 30 * 24 * 60 * 60 * 1000

/** Pages de lecture où une fenêtre d'inscription est pertinente : lecture
 *  longue, engagement fort. Les autres (accueil, boutique, contact, légales,
 *  admin, formulaire) portent déjà leur propre point de collecte actif. */
function pageDeLecture(): boolean {
  const chemin = window.location.pathname
  return (
    chemin.startsWith('/journal') ||
    chemin.startsWith('/histoires') ||
    chemin.startsWith('/xplore') ||
    chemin.startsWith('/taste-and-travel') ||
    chemin.startsWith('/destinations')
  )
}

type Statut = 'idle' | 'erreur' | 'invalide' | 'existe' | 'succes'

export function FenetreNewsletter() {
  const { t } = useLangue()
  const [ouverte, setOuverte] = useState(false)
  const [email, setEmail] = useState('')
  const [statut, setStatut] = useState<Statut>('idle')
  const boutonFermer = useRef<HTMLButtonElement>(null)

  const fermer = () => {
    setOuverte(false)
    try {
      window.localStorage.setItem(CLE_MODAL_VERROU, String(Date.now() + DUR_MODALE_FERME))
    } catch {
      /* Stockage indisponible : la modale ne se re-fermera pas avant expiration. */
    }
  }

  // Une fois, après ~20 s, hors des fenêtres déjà couvertes par un point de
  // collecte actif (abonné connu, verrou de fermeture, autre fenêtre ouverte).
  useEffect(() => {
    if (!pageDeLecture()) return
    const verrou = Number(window.localStorage.getItem(CLE_MODAL_VERROU) ?? 0)
    const marque = window.localStorage.getItem('pe_newsletter_abonnes')
    const autorise = !verrou || Date.now() > verrou + DUR_MODALE_FERME
    if (!autorise || marque) return

    const minute = window.setTimeout(() => setOuverte(true), DUR_MODALE_PRESENCE * 1000)
    return () => window.clearTimeout(minute)
  }, [])

  // Fermeture au clavier, focus amarré, bloquage du scroll sous la fenêtre.
  useEffect(() => {
    if (!ouverte) return
    const touche = (evenement: KeyboardEvent) => {
      if (evenement.key === 'Escape') fermer()
    }
    const precedent = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', touche)
    boutonFermer.current?.focus()
    return () => {
      document.body.style.overflow = precedent
      window.removeEventListener('keydown', touche)
    }
  }, [ouverte])

  const inscription = (evenement: FormEvent<HTMLFormElement>) => {
    evenement.preventDefault()
    if (!emailValide(email)) {
      setStatut('invalide')
      return
    }
    if (estInscrit(email)) {
      setStatut('existe')
      return
    }
    consignerIntention({
      email,
      consentement: {
        date: new Date().toISOString(),
        version: VERSION_CONSENTEMENT,
        source: window.location.pathname,
      },
    })
    marquerInscrit({ email })
    setStatut('succes')
  }

  if (!ouverte) return null

  return (
    <AnimatePresence>
      {ouverte ? (
        <motion.div
          key="fenetre-newsletter"
          className="fixed inset-0 z-[80] flex items-center justify-center bg-night-900/70 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25, ease: EASE_EXPO }}
          onClick={(evenement) => {
            if (evenement.target === evenement.currentTarget) fermer()
          }}
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={t('newsletter.titre')}
            className="w-full max-w-md rounded-xl bg-sand-100 p-6 text-ink-900 sm:p-8"
            initial={{ y: 24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 24, opacity: 0 }}
            transition={{ duration: DUR.base, ease: EASE_EXPO }}
          >
            {statut === 'succes' ? (
              <div className="space-y-6">
                <SectionHeading
                  eyebrow={t('newsletter.titre')}
                  title={
                    <>
                      Recevoir la lettre
                      <span aria-hidden className="text-clay-500">.</span>
                    </>
                  }
                />
                <p className="text-body-lg text-ink-700">{t('newsletter.confirme')}</p>
                <Button variant="dark" magnetic={false} onClick={fermer}>
                  {t('newsletter.retourAccueil')}
                </Button>
              </div>
            ) : (
              <form className="space-y-5" onSubmit={inscription}>
                <div className="space-y-3">
                  <p className="label-caps text-clay-600">{t('newsletter.titre')}</p>
                  <p className="text-body text-ink-700">{PROMESSE_NEWSLETTER}</p>
                </div>
                <div className="space-y-4">
                  <label className="block">
                    <span className="label-caps text-ink-500">{t('newsletter.email')}</span>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(evenement) => {
                        setEmail(evenement.target.value)
                        setStatut('idle')
                      }}
                      placeholder={t('newsletter.email')}
                      aria-label={t('newsletter.email')}
                      className="mt-2 w-full rounded-md border border-sand-200 bg-transparent px-4 py-3 text-body text-ink-900"
                    />
                  </label>
                  {statut === 'invalide' ? (
                    <p role="alert" className="text-caption font-semibold text-clay-700">
                      {t('newsletter.emailInvalide')}
                    </p>
                  ) : null}
                  {statut === 'existe' ? (
                    <p role="alert" className="text-caption font-semibold text-ink-500">
                      {t('newsletter.dejaInscrit')}
                    </p>
                  ) : null}
                  {statut === 'erreur' ? (
                    <p role="alert" className="text-caption font-semibold text-clay-700">
                      {t('newsletter.inscriptionEchoue')}
                    </p>
                  ) : null}
                </div>
                <Button type="submit" magnetic={false}>
                  {t('newsletter.cta')}
                </Button>
              </form>
            )}
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}
